Add-Type -AssemblyName System.Drawing

$iconDir = 'C:\Users\manis\.gemini\antigravity\scratch\scroll-disruptor\icons'
if (!(Test-Path $iconDir)) { New-Item -ItemType Directory -Path $iconDir -Force | Out-Null }

$sizes = @(16, 48, 128)

foreach ($sz in $sizes) {
    $bmp = New-Object System.Drawing.Bitmap($sz, $sz)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic

    # Transparent background to blend in natively
    $g.Clear([System.Drawing.Color]::Transparent)

    # Crimson red
    $crimson = [System.Drawing.Color]::FromArgb(255, 220, 20, 60)
    $pen = New-Object System.Drawing.Pen($crimson, [float]($sz * 0.08))
    $pen.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
    $pen.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
    $pen.LineJoin = [System.Drawing.Drawing2D.LineJoin]::Round

    # Left checkmark (forming left wing and right top point)
    $p1 = New-Object System.Drawing.PointF([float]($sz * 0.15), [float]($sz * 0.60))
    $p2 = New-Object System.Drawing.PointF([float]($sz * 0.35), [float]($sz * 0.85))
    $p3 = New-Object System.Drawing.PointF([float]($sz * 0.85), [float]($sz * 0.15))
    $g.DrawLines($pen, @($p1, $p2, $p3))

    # Right checkmark (forming right wing and left top point)
    $p4 = New-Object System.Drawing.PointF([float]($sz * 0.85), [float]($sz * 0.60))
    $p5 = New-Object System.Drawing.PointF([float]($sz * 0.65), [float]($sz * 0.85))
    $p6 = New-Object System.Drawing.PointF([float]($sz * 0.15), [float]($sz * 0.15))
    $g.DrawLines($pen, @($p4, $p5, $p6))

    $outPath = Join-Path $iconDir ('icon' + $sz.ToString() + '.png')
    $bmp.Save($outPath, [System.Drawing.Imaging.ImageFormat]::Png)

    $g.Dispose()
    $bmp.Dispose()
    $pen.Dispose()
    
    Write-Host ('Created: ' + $outPath)
}
