/**
 * ANTI-DOOMSCROLL — Popup Entry Point
 * Initialises the shared UI in "popup" layout mode.
 */
document.addEventListener('DOMContentLoaded', () => {
  ScrollDisruptorUI.init('popup');

  const openSidebarBtn = document.getElementById('open-sidebar-btn');
  if (openSidebarBtn) {
    openSidebarBtn.addEventListener('click', () => {
      chrome.windows.getCurrent({ populate: false }, (win) => {
        chrome.sidePanel.open({ windowId: win.id });
        window.close(); // Close the popup after opening the sidebar
      });
    });
  }
});
