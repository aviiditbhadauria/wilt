'use strict';

/* ============================================================
 * ANTI-DOOMSCROLL — Background Service Worker
 * ============================================================
 * Responsibilities:
 *   1. Track active time on blacklisted tabs, PERSISTENT per domain.
 *   2. Support custom websites & custom time thresholds.
 *   3. SPA (Single Page Application) routing awareness.
 *   4. Inject content scripts and push friction levels.
 *   5. Serve tracking data to popup / sidebar views.
 * ============================================================ */

const DEFAULT_SITES = {
  'youtube.com':   { enabled: true, label: 'YouTube' },
  'instagram.com': { enabled: true, label: 'Instagram' },
  'facebook.com':  { enabled: true, label: 'Facebook' },
  'reddit.com':    { enabled: true, label: 'Reddit' },
  'x.com':         { enabled: true, label: 'X (Twitter)' },
  'tiktok.com':    { enabled: true, label: 'TikTok' }
};

const DEFAULT_THRESHOLDS = [1, 3, 5];
const ALARM_NAME   = 'scroll-disruptor-tick';
const DAILY_RESET_ALARM = 'scroll-disruptor-daily-reset';
const ALARM_PERIOD = 0.1; // Check frequently (every 6 seconds)

// In-Memory State
let tabState = {}; // tabId -> { domain, startTime, injected, lastLevel }
let activeTabId = null;
let domainTotals = {}; // domain -> totalMs

chrome.runtime.onInstalled.addListener(async () => {
  const stored = await chrome.storage.local.get([
    'customSites', 'defaultSites', 'thresholds', 'enabled', 'domainTotals', 'lastResetDate'
  ]);

  if (!stored.defaultSites)           await chrome.storage.local.set({ defaultSites: DEFAULT_SITES });
  if (!stored.customSites)            await chrome.storage.local.set({ customSites: [] });
  if (!stored.thresholds)             await chrome.storage.local.set({ thresholds: DEFAULT_THRESHOLDS });
  if (stored.enabled === undefined)   await chrome.storage.local.set({ enabled: true });
  if (!stored.domainTotals)           await chrome.storage.local.set({ domainTotals: {} });
  if (!stored.lastResetDate)          await chrome.storage.local.set({ lastResetDate: new Date().toDateString() });

  try { await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }); } catch {}
  scheduleAlarms();
});

chrome.runtime.onStartup.addListener(async () => {
  scheduleAlarms();
  await restoreState();
  await checkAndResetDaily();
});

restoreState();

function scheduleAlarms() {
  chrome.alarms.create(ALARM_NAME, { periodInMinutes: ALARM_PERIOD });

  const nextMidnight = new Date();
  nextMidnight.setHours(24, 0, 0, 0);
  chrome.alarms.create(DAILY_RESET_ALARM, {
    when: nextMidnight.getTime(),
    periodInMinutes: 24 * 60
  });
}

async function persistState() {
  try {
    await chrome.storage.session.set({ tabState, activeTabId });
  } catch {}
}

async function restoreState() {
  try {
    const data = await chrome.storage.session.get(['tabState', 'activeTabId']);
    const local = await chrome.storage.local.get(['domainTotals']);
    
    if (local.domainTotals) domainTotals = local.domainTotals;
    
    if (data.tabState) {
      tabState = data.tabState;
      // Reset start times for active tracking upon restart
      for (const state of Object.values(tabState)) {
        if (state.startTime) state.startTime = Date.now();
      }
    }
    if (data.activeTabId) activeTabId = data.activeTabId;
  } catch {}
}

async function checkAndResetDaily() {
  const stored = await chrome.storage.local.get(['lastResetDate', 'domainTotals']);
  const today = new Date().toDateString();
  
  if (stored.lastResetDate !== today) {
    await resetAllTimers(today);
    return true;
  }
  return false;
}

async function resetAllTimers(resetDate = new Date().toDateString()) {
  domainTotals = {};
  await chrome.storage.local.set({ domainTotals, lastResetDate: resetDate });

  for (const [id, state] of Object.entries(tabState)) {
    state.startTime = state.startTime ? Date.now() : null;
    state.lastLevel = 0;
    await pushFrictionLevel(Number(id), 0);
  }
  await persistState();
}

function extractDomain(url) {
  try {
    if (!url || url.startsWith('chrome') || url.startsWith('about') || url.startsWith('file')) return null;
    return new URL(url).hostname.replace(/^www\./, '');
  } catch { return null; }
}

async function isBlacklisted(domain) {
  if (!domain) return false;

  const { defaultSites, customSites, enabled } =
    await chrome.storage.local.get(['defaultSites', 'customSites', 'enabled']);

  if (enabled === false) return false;

  const defaults = defaultSites || DEFAULT_SITES;
  for (const [site, config] of Object.entries(defaults)) {
    if (config.enabled && domain.endsWith(site)) return true;
  }

  for (const site of (customSites || [])) {
    if (domain.endsWith(site.domain)) return true;
  }

  return false;
}

// Commits the active tab's elapsed time to the persistent domainTotals dictionary.
function commitActiveTime() {
  if (activeTabId && tabState[activeTabId] && tabState[activeTabId].startTime) {
    const domain = tabState[activeTabId].domain;
    const elapsed = Date.now() - tabState[activeTabId].startTime;
    
    if (!domainTotals[domain]) domainTotals[domain] = 0;
    domainTotals[domain] += elapsed;
    
    tabState[activeTabId].startTime = Date.now(); // Reset for next tick
    chrome.storage.local.set({ domainTotals }).catch(() => {});
  }
}

async function getFrictionLevel(domain) {
  const { thresholds } = await chrome.storage.local.get('thresholds');
  const t = thresholds || DEFAULT_THRESHOLDS;
  
  // Base total from storage
  let totalMs = domainTotals[domain] || 0;
  
  // Add any uncommitted time from the currently active tab
  if (activeTabId && tabState[activeTabId] && tabState[activeTabId].domain === domain && tabState[activeTabId].startTime) {
    totalMs += Date.now() - tabState[activeTabId].startTime;
  }

  const minutes = totalMs / 60_000;

  if (minutes >= t[2]) return 3;
  if (minutes >= t[1]) return 2;
  if (minutes >= t[0]) return 1;
  return 0;
}

async function injectContentScript(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: 'PING' });
    return true; 
  } catch {
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
      return true;
    } catch (err) {
      return false;
    }
  }
}

async function pushFrictionLevel(tabId, level, isSPA = false) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: 'SET_FRICTION_LEVEL', level, isSPA });
  } catch {}
}

// ── Tab Event Handlers (SPA handling included) ────────────────

chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (!info.url && info.status !== 'complete') return;

  const url    = info.url || tab.url;
  const domain = extractDomain(url);
  const listed = await isBlacklisted(domain);

  if (listed) {
    let isSPA = false;
    
    // Commit time before changing domains if this tab was active
    if (tabId === activeTabId && tabState[tabId] && tabState[tabId].domain !== domain) {
      commitActiveTime();
    }
    
    if (!tabState[tabId] || tabState[tabId].domain !== domain) {
      tabState[tabId] = {
        domain,
        startTime:   tabId === activeTabId ? Date.now() : null, // Only start tracking if active
        injected:    false,
        lastLevel:   0
      };
    } else if (info.url && tabState[tabId].domain === domain) {
      isSPA = true;
    }

    if (info.status === 'complete' || isSPA) {
      tabState[tabId].injected = await injectContentScript(tabId);

      if (tabState[tabId].injected) {
        const level = await getFrictionLevel(domain);
        tabState[tabId].lastLevel = level;
        
        if (level > 0 || isSPA) await pushFrictionLevel(tabId, level, isSPA);
      }
    }
    await persistState();
  } else if (tabState[tabId]) {
    // Navigated away from a blacklisted site
    if (tabId === activeTabId) commitActiveTime();
    
    try { await chrome.tabs.sendMessage(tabId, { type: 'CLEAR_EFFECTS' }); } catch {}
    delete tabState[tabId];
    await persistState();
  }
});

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  // Commit time for the outgoing tab
  commitActiveTime();

  if (activeTabId && tabState[activeTabId]) {
    tabState[activeTabId].startTime = null; // Pause tracking
  }

  activeTabId = tabId;

  if (tabState[tabId]) {
    tabState[tabId].startTime = Date.now(); // Resume tracking
  } else {
    try {
      const tab = await chrome.tabs.get(tabId);
      const domain = extractDomain(tab.url);
      if (domain && await isBlacklisted(domain)) {
        tabState[tabId] = { domain, startTime: Date.now(), injected: false, lastLevel: 0 };
        tabState[tabId].injected = await injectContentScript(tabId);
      }
    } catch {}
  }

  await persistState();
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  if (activeTabId === tabId) commitActiveTime();
  delete tabState[tabId];
  if (activeTabId === tabId) activeTabId = null;
  await persistState();
});

// ── Alarms ────────────────────────────────────────────────────

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === DAILY_RESET_ALARM) {
    await checkAndResetDaily();
    return;
  }
  if (alarm.name !== ALARM_NAME) return;

  // Reset regardless of whether monitoring is currently enabled.
  await checkAndResetDaily();

  const { enabled } = await chrome.storage.local.get('enabled');
  if (enabled === false) return;

  // Sync active time to domainTotals
  commitActiveTime();

  // Evaluate friction levels for all tracked tabs
  for (const [idStr, state] of Object.entries(tabState)) {
    const tabId = Number(idStr);
    const newLevel = await getFrictionLevel(state.domain);

    if (newLevel !== state.lastLevel) {
      state.lastLevel = newLevel;

      if (!state.injected) {
        state.injected = await injectContentScript(tabId);
      }
      if (state.injected) {
        await pushFrictionLevel(tabId, newLevel);
      }
    }
  }

  await persistState();
});

// ── UI Messages ───────────────────────────────────────────────

function buildTrackingSnapshot() {
  const out = {};
  for (const [domain, total] of Object.entries(domainTotals)) {
    // Add uncommitted time for active tab if it matches this domain
    let currentTotal = total;
    if (activeTabId && tabState[activeTabId] && tabState[activeTabId].domain === domain && tabState[activeTabId].startTime) {
      currentTotal += (Date.now() - tabState[activeTabId].startTime);
    }
    
    // We don't have level calculated synchronously here, but ui-shared.js calculates level via thresholds, 
    // wait, actually ui-shared.js relied on background to send level. 
    // I will just return the level here.
    out[domain] = { domain, totalTime: currentTotal };
  }
  
  // Also include active tab even if it has 0 total in domainTotals yet
  if (activeTabId && tabState[activeTabId]) {
    const domain = tabState[activeTabId].domain;
    if (!out[domain]) {
      const elapsed = tabState[activeTabId].startTime ? (Date.now() - tabState[activeTabId].startTime) : 0;
      out[domain] = { domain, totalTime: elapsed };
    }
  }
  
  return out;
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  switch (msg.type) {
    case 'GET_TRACKING_DATA':
      // Since getFrictionLevel is async, we evaluate levels for the snapshot
      (async () => {
        const snap = buildTrackingSnapshot();
        for (const domain of Object.keys(snap)) {
          snap[domain].level = await getFrictionLevel(domain);
        }
        reply({ trackingData: snap });
      })();
      return true; // Keep channel open for async response
      
    case 'RESET_ALL_TIMERS':
      resetAllTimers().then(() => reply({ ok: true }));
      return true;
      
    case 'TOGGLE_ENABLED':
      chrome.storage.local.set({ enabled: msg.enabled });
      if (!msg.enabled) {
        for (const id of Object.keys(tabState)) {
          pushFrictionLevel(Number(id), 0);
        }
        tabState = {};
        persistState();
      }
      reply({ ok: true });
      return false;
  }
});
