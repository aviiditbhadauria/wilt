Add-Type -AssemblyName System.Drawing

$iconDir = 'C:\Users\manis\.gemini\antigravity\scratch\scroll-disruptor\icons'
New-Item -ItemType Directory -Path $iconDir -Force | Out-Null

$sizes = @(16, 48, 128)

foreach ($sz in $sizes) {
    $bmp = New-Object System.Drawing.Bitmap($sz, $sz)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality

    $g.Clear([System.Drawing.Color]::Transparent)

    # Crimson red filled circle
    $crimson = [System.Drawing.Color]::FromArgb(255, 220, 20, 60)
    $brush = New-Object System.Drawing.SolidBrush($crimson)
    $pad = [Math]::Max(0, [int]($sz * 0.03))
    $g.FillEllipse($brush, $pad, $pad, $sz - 2 * $pad - 1, $sz - 2 * $pad - 1)

    # Dark border
    $darkRed = [System.Drawing.Color]::FromArgb(255, 160, 16, 48)
    $penW = [Math]::Max(1, [int]($sz / 16))
    $pen = New-Object System.Drawing.Pen($darkRed, $penW)
    $g.DrawEllipse($pen, $pad, $pad, $sz - 2 * $pad - 1, $sz - 2 * $pad - 1)

    # White "SD" text
    $fontSize = [Math]::Max(5, $sz * 0.32)
    $font = New-Object System.Drawing.Font('Segoe UI', [float]$fontSize, [System.Drawing.FontStyle]::Bold)
    $textBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::White)
    $format = New-Object System.Drawing.StringFormat
    $format.Alignment = [System.Drawing.StringAlignment]::Center
    $format.LineAlignment = [System.Drawing.StringAlignment]::Center
    $rect = New-Object System.Drawing.RectangleF(0, 0, [float]$sz, [float]$sz)
    $g.DrawString('SD', $font, $textBrush, $rect, $format)

    $outPath = Join-Path $iconDir ('icon' + $sz.ToString() + '.png')
    $bmp.Save($outPath, [System.Drawing.Imaging.ImageFormat]::Png)

    $g.Dispose()
    $bmp.Dispose()
    $brush.Dispose()
    $pen.Dispose()
    $font.Dispose()
    $textBrush.Dispose()
    $format.Dispose()

    Write-Host ('Created: ' + $outPath)
}

Write-Host 'Done.'
