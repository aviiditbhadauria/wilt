/**
 * Progressive visual friction for monitored pages.
 * Effects are deliberately applied with inline styles and event listeners so
 * they remain isolated to the currently monitored document.
 */
(() => {
  'use strict';

  if (window.__doomscrollInjected) return;
  window.__doomscrollInjected = true;

  const INTERACTION_DELAY_MIN = 3_000;
  const INTERACTION_DELAY_MAX = 5_000;
  const RENDER_DELAY = 2_500;
  const OVERLAY_INTERVAL = 7_000;
  const OVERLAY_DURATION = 280;

  let currentLevel = 0;
  let overlay = null;
  let blackoutTimer = null;
  let mutationObserver = null;
  let replayingInteraction = false;
  const textOriginals = new Map();
  const styleOriginals = new Map();
  const deferredTimers = new Set();

  function rememberStyle(element, property) {
    if (!styleOriginals.has(element)) styleOriginals.set(element, new Map());
    const styles = styleOriginals.get(element);
    if (!styles.has(property)) {
      styles.set(property, {
        value: element.style.getPropertyValue(property),
        priority: element.style.getPropertyPriority(property)
      });
    }
  }

  function setStyle(element, property, value, priority = 'important') {
    rememberStyle(element, property);
    element.style.setProperty(property, value, priority);
  }

  function restoreStyles() {
    for (const [element, styles] of styleOriginals) {
      for (const [property, original] of styles) {
        if (original.value) element.style.setProperty(property, original.value, original.priority);
        else element.style.removeProperty(property);
      }
    }
    styleOriginals.clear();
  }

  function applyFriction(level, isSPA = false) {
    const nextLevel = Math.max(0, Math.min(3, Number(level) || 0));
    const changed = nextLevel !== currentLevel;

    if (changed) clearAllEffects();
    currentLevel = nextLevel;
    if (!currentLevel) return;

    // Tier 1: monochrome page, intermittent black-screen interruption, and lag.
    applyMildEffects();

    // Tier 2 retains Tier 1 while delaying newly rendered page content and
    // jumbling readable text. Images and video are intentionally untouched.
    if (currentLevel >= 2) applyMediumEffects(document);

    // Tier 3 adds the media barrier and blocks every page interaction.
    if (currentLevel >= 3) applyMaxEffects();

    startMutationObserver();
    if (isSPA && currentLevel >= 2) applyMediumEffects(document);
  }

  function applyMildEffects() {
    setStyle(document.documentElement, 'filter', 'grayscale(100%)');
    setStyle(document.documentElement, 'transition', 'filter 350ms ease');
    createBlackoutOverlay();
    flashBlackout();
    window.addEventListener('click', delayInteraction, true);
    window.addEventListener('auxclick', delayInteraction, true);
    window.addEventListener('submit', delayFormSubmit, true);
  }

  function createBlackoutOverlay() {
    if (overlay) return;
    overlay = document.createElement('div');
    overlay.dataset.scrollDisruptorOverlay = 'true';
    Object.assign(overlay.style, {
      position: 'fixed', inset: '0', zIndex: '2147483647', background: '#000',
      opacity: '0', pointerEvents: 'none', transition: 'opacity 120ms ease'
    });
    (document.documentElement || document.body).appendChild(overlay);
    blackoutTimer = window.setInterval(flashBlackout, OVERLAY_INTERVAL);
  }

  function flashBlackout() {
    if (!overlay || currentLevel < 1) return;
    overlay.style.opacity = '1';
    const timer = window.setTimeout(() => {
      if (overlay) overlay.style.opacity = '0';
      deferredTimers.delete(timer);
    }, OVERLAY_DURATION);
    deferredTimers.add(timer);
  }

  function delayInteraction(event) {
    if (currentLevel < 1 || currentLevel >= 3 || replayingInteraction || !event.isTrusted) return;
    const target = event.target instanceof Element ? event.target.closest('a, button, input, textarea, select, [role="button"], [contenteditable="true"]') : null;
    if (!target) return;

    event.preventDefault();
    event.stopImmediatePropagation();
    const delay = INTERACTION_DELAY_MIN + Math.random() * (INTERACTION_DELAY_MAX - INTERACTION_DELAY_MIN);
    const timer = window.setTimeout(() => {
      deferredTimers.delete(timer);
      if (currentLevel < 1 || currentLevel >= 3 || !target.isConnected) return;
      replayingInteraction = true;
      try {
        target.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
        if (target.matches('input, textarea, select, [contenteditable="true"]')) target.focus();
      } finally {
        replayingInteraction = false;
      }
    }, delay);
    deferredTimers.add(timer);
  }

  function delayFormSubmit(event) {
    if (currentLevel < 1 || currentLevel >= 3 || replayingInteraction || !event.isTrusted) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    const form = event.target;
    const timer = window.setTimeout(() => {
      deferredTimers.delete(timer);
      if (currentLevel < 1 || currentLevel >= 3 || !form.isConnected) return;
      replayingInteraction = true;
      try { form.requestSubmit(); } finally { replayingInteraction = false; }
    }, INTERACTION_DELAY_MIN + Math.random() * (INTERACTION_DELAY_MAX - INTERACTION_DELAY_MIN));
    deferredTimers.add(timer);
  }

  function applyMediumEffects(root) {
    scrambleText(root);
  }

  function scrambleText(root) {
    const containers = root.querySelectorAll ? root.querySelectorAll('p, h1, h2, h3, h4, h5, h6, span') : [];
    containers.forEach(element => {
      if (element.closest('script, style, noscript, textarea, input, [contenteditable="true"], [data-scroll-disruptor-overlay]')) return;
      element.childNodes.forEach(node => {
        if (node.nodeType !== Node.TEXT_NODE || node.textContent.trim().length < 4) return;
        if (!textOriginals.has(node)) textOriginals.set(node, node.textContent);
        node.textContent = scrambleString(textOriginals.get(node));
      });
    });
  }

  function scrambleString(value) {
    return value.replace(/\b([\p{L}\p{N}])([\p{L}\p{N}]{2,})([\p{L}\p{N}])\b/gu, (_word, first, middle, last) => {
      const letters = [...middle];
      for (let index = letters.length - 1; index > 0; index--) {
        const swapIndex = Math.floor(Math.random() * (index + 1));
        [letters[index], letters[swapIndex]] = [letters[swapIndex], letters[index]];
      }
      return `${first}${letters.join('')}${last}`;
    });
  }

  function delayNewContent(nodes) {
    const elements = [...nodes].filter(node => node.nodeType === Node.ELEMENT_NODE && !node.dataset.scrollDisruptorOverlay);
    elements.forEach(element => {
      setStyle(element, 'visibility', 'hidden');
      const timer = window.setTimeout(() => {
        deferredTimers.delete(timer);
        if (currentLevel < 2 || !element.isConnected) return;
        const original = styleOriginals.get(element)?.get('visibility');
        if (original?.value) element.style.setProperty('visibility', original.value, original.priority);
        else element.style.removeProperty('visibility');
        scrambleText(element);
      }, RENDER_DELAY);
      deferredTimers.add(timer);
    });
  }

  function applyMaxEffects() {
    document.querySelectorAll('img, video, canvas').forEach(element => {
      setStyle(element, 'filter', 'blur(18px)');
      setStyle(element, 'transition', 'filter 350ms ease');
    });
    setStyle(document.documentElement, 'overflow', 'hidden');
    setStyle(document.body, 'overflow', 'hidden');
    setStyle(document.body, 'pointer-events', 'none');
    const blockedEvents = ['pointerdown', 'pointerup', 'click', 'dblclick', 'auxclick', 'contextmenu', 'wheel', 'touchstart', 'touchmove', 'touchend', 'keydown', 'keyup', 'keypress', 'beforeinput', 'input', 'change', 'focusin', 'submit', 'dragstart', 'drop'];
    blockedEvents.forEach(type => window.addEventListener(type, blockInteraction, { capture: true, passive: false }));
  }

  function blockInteraction(event) {
    if (currentLevel < 3) return;
    event.preventDefault();
    event.stopImmediatePropagation();
  }

  function startMutationObserver() {
    if (mutationObserver || !document.body) return;
    mutationObserver = new MutationObserver(mutations => {
      const addedNodes = mutations.flatMap(mutation => [...mutation.addedNodes]);
      if (!addedNodes.length) return;
      if (currentLevel >= 2) delayNewContent(addedNodes);
      if (currentLevel >= 3) applyMaxEffects();
    });
    mutationObserver.observe(document.body, { childList: true, subtree: true });
  }

  function clearAllEffects() {
    window.removeEventListener('click', delayInteraction, true);
    window.removeEventListener('auxclick', delayInteraction, true);
    window.removeEventListener('submit', delayFormSubmit, true);
    ['pointerdown', 'pointerup', 'click', 'dblclick', 'auxclick', 'contextmenu', 'wheel', 'touchstart', 'touchmove', 'touchend', 'keydown', 'keyup', 'keypress', 'beforeinput', 'input', 'change', 'focusin', 'submit', 'dragstart', 'drop'].forEach(type => window.removeEventListener(type, blockInteraction, true));
    if (mutationObserver) mutationObserver.disconnect();
    mutationObserver = null;
    if (blackoutTimer) clearInterval(blackoutTimer);
    blackoutTimer = null;
    if (overlay) overlay.remove();
    overlay = null;
    deferredTimers.forEach(timer => clearTimeout(timer));
    deferredTimers.clear();
    restoreStyles();
    for (const [node, original] of textOriginals) {
      if (node.isConnected) node.textContent = original;
    }
    textOriginals.clear();
    currentLevel = 0;
  }

  chrome.runtime.onMessage.addListener((message, _sender, reply) => {
    if (message.type === 'SET_FRICTION_LEVEL') applyFriction(message.level, message.isSPA);
    if (message.type === 'CLEAR_EFFECTS') clearAllEffects();
    if (message.type === 'PING' || message.type === 'SET_FRICTION_LEVEL' || message.type === 'CLEAR_EFFECTS') reply({ ok: true });
  });
})();
