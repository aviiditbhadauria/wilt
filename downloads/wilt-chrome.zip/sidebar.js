/**
 * SCROLL DISRUPTOR — Sidebar Entry Point
 * Initialises the shared UI in "sidebar" layout mode.
 */
document.addEventListener('DOMContentLoaded', () => {
  ScrollDisruptorUI.init('sidebar');

  const closeSidebarBtn = document.getElementById('close-sidebar-btn');
  if (closeSidebarBtn) {
    closeSidebarBtn.addEventListener('click', () => {
      // Closes the side panel view
      window.close();
    });
  }
});
