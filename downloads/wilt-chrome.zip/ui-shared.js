/**
 * ============================================================
 * SCROLL DISRUPTOR — Shared UI Module
 * ============================================================
 * Single module consumed by both popup.js and sidebar.js.
 * Renders settings, manages state, and communicates with the
 * background service worker.
 */
const ScrollDisruptorUI = (() => {
  'use strict';

  const SITE_META = {
    'youtube.com':   { label: 'YouTube',   icon: '▶️' },
    'instagram.com': { label: 'Instagram', icon: '📸' },
    'facebook.com':  { label: 'Facebook',  icon: '👤' },
    'reddit.com':    { label: 'Reddit',    icon: '🔴' },
    'x.com':         { label: 'X (Twitter)', icon: '✖️' },
    'tiktok.com':    { label: 'TikTok',    icon: '🎵' }
  };

  let refreshTimer = null;

  async function init(viewType) {
    document.body.classList.add(viewType === 'sidebar' ? 'sidebar-view' : 'popup-view');

    const { defaultSites, customSites, thresholds, enabled } =
      await chrome.storage.local.get(['defaultSites', 'customSites', 'thresholds', 'enabled']);

    const toggle = document.getElementById('enabled-toggle');
    toggle.checked = enabled !== false;
    toggle.addEventListener('change', onMasterToggle);
    refreshStatusBanner(enabled !== false);

    renderDefaultSites(defaultSites || {
      'youtube.com':   { enabled: true, label: 'YouTube' },
      'instagram.com': { enabled: true, label: 'Instagram' },
      'facebook.com':  { enabled: true, label: 'Facebook' },
      'reddit.com':    { enabled: true, label: 'Reddit' },
      'x.com':         { enabled: true, label: 'X (Twitter)' },
      'tiktok.com':    { enabled: true, label: 'TikTok' }
    });
    
    renderCustomSites(customSites || []);
    renderThresholds(thresholds || [1, 3, 5]);

    document.getElementById('add-custom-btn').addEventListener('click', onAddCustomSite);
    document.getElementById('custom-url-input').addEventListener('keydown', e => {
      if (e.key === 'Enter') onAddCustomSite();
    });
    document.getElementById('save-thresholds-btn').addEventListener('click', onSaveThresholds);
    document.getElementById('reset-all-btn').addEventListener('click', onResetAll);
    const restoreBtn = document.getElementById('restore-defaults-btn');
    if (restoreBtn) restoreBtn.addEventListener('click', onRestoreDefaults);

    refreshSessions();
    refreshTimer = setInterval(refreshSessions, 1000);

    chrome.storage.onChanged.addListener(onStorageChanged);
  }

  function refreshStatusBanner(active) {
    const dot  = document.querySelector('.status-dot');
    const text = document.querySelector('.status-text');
    const bar  = document.getElementById('status-banner');

    if (active) {
      dot.style.backgroundColor = '#22c55e';
      dot.style.boxShadow       = '0 0 6px #14532d';
      text.textContent          = 'Monitoring active';
      bar.style.borderColor     = '#1a3a26';
    } else {
      dot.style.backgroundColor = '#555';
      dot.style.boxShadow       = 'none';
      text.textContent          = 'Monitoring paused';
      bar.style.borderColor     = '#292929';
    }
  }

  function renderDefaultSites(sites) {
    const list = document.getElementById('default-sites-list');
    list.innerHTML = '';

    for (const [domain, config] of Object.entries(sites)) {
      const meta = SITE_META[domain] || { label: domain, icon: '🌐' };

      const row = document.createElement('div');
      row.className = 'site-row';
      row.innerHTML = `
        <div class="site-info">
          <img class="site-logo" src="https://www.google.com/s2/favicons?domain=${domain}&sz=64" alt="">
          <span class="site-domain">${meta.label}</span>
        </div>
        <label class="toggle-switch small">
          <input type="checkbox" ${config.enabled ? 'checked' : ''}>
          <span class="toggle-slider"></span>
        </label>`;

      const cb = row.querySelector('input');
      cb.addEventListener('change', () => onToggleDefaultSite(domain, cb.checked));
      list.appendChild(row);
    }
  }

  function renderCustomSites(sites) {
    const list = document.getElementById('custom-sites-list');
    list.innerHTML = '';

    if (!sites.length) {
      list.innerHTML = '<p class="empty-state-small">No custom sites added</p>';
      return;
    }

    sites.forEach((site, idx) => {
      const row = document.createElement('div');
      row.className = 'site-row custom';
      row.innerHTML = `
        <div class="site-info">
          <img class="site-logo" src="https://www.google.com/s2/favicons?domain=${site.domain}&sz=64" alt="">
          <span class="site-domain">${site.domain}</span>
        </div>
        <button class="btn-icon btn-remove" title="Remove">✕</button>`;

      row.querySelector('.btn-remove').addEventListener('click', () => onRemoveCustomSite(idx));
      list.appendChild(row);
    });
  }

  function renderThresholds(t) {
    document.getElementById('threshold-1').value = t[0] || 1;
    document.getElementById('threshold-2').value = t[1] || 3;
    document.getElementById('threshold-3').value = t[2] || 5;
  }

  async function refreshSessions() {
    const container = document.getElementById('sessions-list');

    try {
      const { trackingData } = await chrome.runtime.sendMessage({ type: 'GET_TRACKING_DATA' });

      if (!trackingData || !Object.keys(trackingData).length) {
        container.innerHTML = '<p class="empty-state">No active sessions</p>';
        return;
      }

      container.innerHTML = '';

      const lvlLabel = ['None', 'Mild', 'Medium', 'Heavy'];
      const lvlColor = ['#555', '#f59e0b', '#f97316', '#DC143C'];

      // trackingData is now { domain: { domain, totalTime, level } }
      for (const [domain, info] of Object.entries(trackingData)) {
        const m = Math.floor(info.totalTime / 60000);
        const s = Math.floor((info.totalTime % 60000) / 1000);

        const row = document.createElement('div');
        row.className = 'session-row';
        row.innerHTML = `
          <div class="session-info">
            <span class="session-domain">${domain}</span>
            <span class="session-level" style="color:${lvlColor[info.level]}">
              ${lvlLabel[info.level]} friction
            </span>
          </div>
          <div class="session-time">
            <span class="time-value">${m}m ${String(s).padStart(2, '0')}s</span>
            <div class="friction-bar">
              <div class="friction-fill" style="width:${Math.min(100, (info.level / 3) * 100)}%;background:${lvlColor[info.level]}"></div>
            </div>
          </div>`;
        container.appendChild(row);
      }
    } catch {
      container.innerHTML = '<p class="empty-state">Waiting for background…</p>';
    }
  }

  async function onMasterToggle(e) {
    const on = e.target.checked;
    await chrome.runtime.sendMessage({ type: 'TOGGLE_ENABLED', enabled: on });
    await chrome.storage.local.set({ enabled: on });
    refreshStatusBanner(on);
  }

  async function onToggleDefaultSite(domain, on) {
    const { defaultSites } = await chrome.storage.local.get('defaultSites');
    if (defaultSites?.[domain]) defaultSites[domain].enabled = on;
    await chrome.storage.local.set({ defaultSites });
  }

  async function onAddCustomSite() {
    const input = document.getElementById('custom-url-input');
    let domain = input.value.trim().toLowerCase();
    if (!domain) return;

    domain = domain.replace(/^(https?:\/\/)?(www\.)?/, '').replace(/\/.*$/, '');

    const blocked = ['chrome:', 'chrome-extension:', 'about:', 'file:', 'javascript:', 'data:'];
    if (blocked.some(b => domain.startsWith(b)) || !domain.includes('.') || domain.length < 4) {
      showToast('Invalid or unsafe domain', 'error');
      return;
    }

    const { customSites, defaultSites } = await chrome.storage.local.get(['customSites', 'defaultSites']);
    const list = customSites || [];

    if (list.some(s => s.domain === domain)) {
      showToast('Already in your list', 'error');
      return;
    }
    if (defaultSites?.[domain]) {
      showToast('Already a default site', 'error');
      return;
    }

    list.push({ domain, addedAt: Date.now() });
    await chrome.storage.local.set({ customSites: list });

    input.value = '';
    renderCustomSites(list);
    showToast('Website added successfully!', 'success');
  }

  async function onRemoveCustomSite(idx) {
    const { customSites } = await chrome.storage.local.get('customSites');
    const list = customSites || [];
    if (idx < 0 || idx >= list.length) return;

    list.splice(idx, 1);
    await chrome.storage.local.set({ customSites: list });
    renderCustomSites(list);
    showToast('Site removed', 'info');
  }

  async function onSaveThresholds() {
    const v1 = parseInt(document.getElementById('threshold-1').value, 10) || 1;
    const v2 = parseInt(document.getElementById('threshold-2').value, 10) || 3;
    const v3 = parseInt(document.getElementById('threshold-3').value, 10) || 5;

    if (v1 >= v2 || v2 >= v3) {
      showToast('Values must be ascending', 'error');
      return;
    }
    if (v1 < 1 || v3 > 120) {
      showToast('Range: 1 – 120 minutes', 'error');
      return;
    }

    await chrome.storage.local.set({ thresholds: [v1, v2, v3] });
    showToast('Thresholds saved successfully!', 'success');
  }

  async function onResetAll() {
    await chrome.runtime.sendMessage({ type: 'RESET_ALL_TIMERS' });
    showToast('All timers reset', 'info');
    refreshSessions();
  }

  async function onRestoreDefaults() {
    if (!confirm('Restore all default settings?')) return;
    const defaults = {
      'youtube.com':   { enabled: true, label: 'YouTube' },
      'instagram.com': { enabled: true, label: 'Instagram' },
      'facebook.com':  { enabled: true, label: 'Facebook' },
      'reddit.com':    { enabled: true, label: 'Reddit' },
      'x.com':         { enabled: true, label: 'X (Twitter)' },
      'tiktok.com':    { enabled: true, label: 'TikTok' }
    };
    await chrome.storage.local.set({
      defaultSites: defaults,
      customSites: [],
      thresholds: [1, 3, 5]
    });
    showToast('Defaults restored', 'success');
  }

  function onStorageChanged(changes, area) {
    if (area !== 'local') return;
    if (changes.customSites)  renderCustomSites(changes.customSites.newValue || []);
    if (changes.defaultSites) renderDefaultSites(changes.defaultSites.newValue || {});
    if (changes.thresholds)   renderThresholds(changes.thresholds.newValue || [1, 3, 5]);
    if (changes.enabled) {
      document.getElementById('enabled-toggle').checked = changes.enabled.newValue !== false;
      refreshStatusBanner(changes.enabled.newValue !== false);
    }
  }

  function showToast(message, type = 'success') {
    const toast   = document.getElementById('success-toast');
    const icon    = toast.querySelector('.toast-icon');
    const textEl  = document.getElementById('toast-message');

    textEl.textContent = message;

    const palette = {
      success: { border: '#287a3e', bg: '#173d22', glyph: '✓', color: '#22c55e' },
      error:   { border: '#842239', bg: '#3b101a', glyph: '✕', color: '#DC143C' },
      info:    { border: '#2859a8', bg: '#102b55', glyph: 'ℹ', color: '#3b82f6' }
    };
    const p = palette[type] || palette.info;

    toast.style.borderColor     = p.border;
    toast.style.backgroundColor = p.bg;
    icon.textContent            = p.glyph;
    icon.style.color            = p.color;

    toast.classList.remove('hidden');
    toast.classList.add('show');

    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => {
      toast.classList.remove('show');
      toast.classList.add('hidden');
    }, 2500);
  }

  return { init };
})();
